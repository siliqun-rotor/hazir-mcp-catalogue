import os
from siliqun_rotor import SiliqunRotorClient
client = SiliqunRotorClient(base_url=os.environ["SQR_BASE_URL"],api_key=os.environ["SQR_API_KEY"])
print(client.run_project_flow(os.environ["SQR_PROJECT_ID"],os.environ["SQR_TASK"]))
