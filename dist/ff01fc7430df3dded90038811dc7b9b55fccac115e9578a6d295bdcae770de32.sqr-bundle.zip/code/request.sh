#!/bin/sh
# Call your installed project through its native authenticated runtime.
# This archive contains no account, destination grant or provider credential.
